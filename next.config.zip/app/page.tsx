'use client';

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * ROOT PAGE — Eneko Ruiz Portfolio
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * FLUJO DE CARGA (sin parpadeos):
 *   'checking' → null (nada renderizado, evita flash en SSR)
 *   'loading'  → <Preloader /> visible, contenido INVISIBLE (opacity:0, h:0)
 *   'splash'   → <IdentitySplash /> visible, contenido INVISIBLE
 *   'ready'    → GSAP recibe el control: fija estados iniciales ANTES del
 *                primer paint y orquesta la entrada con timeline.
 *
 * La clave del fix FOUC: el contenido nunca pasa a opacity:1 por CSS.
 * GSAP es el único actor que lo revela, disparándose con useLayoutEffect
 * (síncrono antes del paint) para garantizar cero parpadeos.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { useEffect, useLayoutEffect, useRef, useState, useCallback } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { Search } from 'lucide-react';

// ── Lib ────────────────────────────────────────────────────────────────────
import { TX, LANG_LABELS } from './lib/translations';
import type { Lang } from './lib/types';

// ── Hooks ──────────────────────────────────────────────────────────────────
import { usePreferredMotion } from './hooks/usePreferredMotion';
import { useGreeting }        from './hooks/useGreeting';
import { useLenis }           from './hooks/useLenis';
import { useGitHub }          from './hooks/useGitHub';

// ── UI components ──────────────────────────────────────────────────────────
import { InfallibleCursor } from './components/ui/InfallibleCursor';
import { Preloader }        from './components/ui/Preloader';
import { LangDD }           from './components/ui/LangDD';
import { ThemeToggle }      from './components/ui/ThemeToggle';
import { CmdModal }         from './components/ui/CmdModal';
import { BranchMergeBtn }   from './components/ui/Buttons';
import { IdentitySplash }   from './components/ui/IdentitySplash';

// ── Section components ─────────────────────────────────────────────────────
import { Hero }       from './components/sections/Hero';
import { About }      from './components/sections/About';
import { Skills }     from './components/sections/Skills';
import { Projects }   from './components/sections/Projects';
import { Philosophy } from './components/sections/Philosophy';
import { Contact }    from './components/sections/Contact';
import { SiteFooter } from './components/sections/SiteFooter';

// Registramos plugins una sola vez en el cliente
if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger, useGSAP);
}

// ── Tipos del ciclo de vida de carga ──────────────────────────────────────
type Phase = 'checking' | 'loading' | 'splash' | 'ready';

export default function Home() {
  // ── Refs ──────────────────────────────────────────────────────────────────
  const main          = useRef<HTMLDivElement>(null);
  const navInner      = useRef<HTMLDivElement>(null);
  const indRef        = useRef<HTMLDivElement>(null);
  const menuRefs      = useRef<(HTMLAnchorElement | null)[]>([]);
  const activeLinkRef = useRef<HTMLAnchorElement | null>(null);

  // ── Estado de la aplicación ───────────────────────────────────────────────
  const [phase, setPhase] = useState<Phase>('checking');
  const [lang,  setLang]  = useState<Lang>('es');
  const [menu,  setMenu]  = useState(false);
  const [cmd,   setCmd]   = useState(false);

  const ready   = phase === 'ready';
  const t       = TX[lang];
  const reduced = usePreferredMotion();
  const greeting = useGreeting(t.times, t.greetingFn);
  const { repos, top3, load, offline } = useGitHub(t);

  useLenis(ready, reduced);

  // ── INICIO DEL FLUJO: Check sessionStorage ─────────────────────────────
  useEffect(() => {
    const hasSeenIntro = sessionStorage.getItem('hasSeenIntro');
    if (hasSeenIntro) {
      setPhase('ready'); // Si ya lo vio, salta directo al portfolio
    } else {
      setPhase('loading'); // Si es nuevo, muestra el Preloader
    }
  }, []);

  // ── Tab title cuando el usuario cambia de pestaña ─────────────────────────
  useEffect(() => {
    const orig = document.title;
    const h = () => {
      document.title = document.hidden ? t.tabAway : t.tabBack;
    };
    document.addEventListener('visibilitychange', h);
    return () => {
      document.removeEventListener('visibilitychange', h);
      document.title = orig;
    };
  }, [t]);

  // ── Bloquea scroll cuando hay modal/menú abierto ──────────────────────────
  useEffect(() => {
    document.body.style.overflow = cmd || menu ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [cmd, menu]);

  // ── Shortcut CMD+F → abre modal de búsqueda ──────────────────────────────
  useEffect(() => {
    const h = (e: globalThis.KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'f') {
        e.preventDefault(); e.stopPropagation();
        setCmd(c => !c);
        return;
      }
      if (e.key === 'Escape') { setCmd(false); setMenu(false); }
    };
    window.addEventListener('keydown', h, { capture: true });
    return () => window.removeEventListener('keydown', h, { capture: true });
  }, []);

  // ── Theme-color del navegador por sección ─────────────────────────────────
  useEffect(() => {
    if (!ready) return;
    const meta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if (!meta) return;

    const map = [
      { id: 'hero',    c: '#f5f5f7' },
      { id: 'skills',  c: '#ffffff' },
      { id: 'work',    c: '#f5f5f7' },
      { id: 'github',  c: '#ffffff' },
      { id: 'about',   c: '#f5f5f7' },
      { id: 'values',  c: '#ffffff' },
      { id: 'contact', c: '#f5f5f7' },
    ];

    const observers = map.map(({ id, c }) => {
      const el = document.getElementById(id);
      if (!el) return null;
      const io = new IntersectionObserver(
        ([e]) => { if (e.isIntersecting) meta.content = c; },
        { threshold: 0.4 }
      );
      io.observe(el);
      return io;
    });
    return () => observers.forEach(io => io?.disconnect());
  }, [ready]);

  // ── Scroll reveal genérico (IntersectionObserver) ─────────────────────────
  useEffect(() => {
    if (!ready) return;
    const io = new IntersectionObserver(
      es => es.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
      }),
      { threshold: 0.1 }
    );
    document.querySelectorAll('.sr').forEach(el => io.observe(el));
    return () => io.disconnect();
  }, [ready, t]);

  // ── Animación del menú overlay (móvil) ────────────────────────────────────
  useEffect(() => {
    menuRefs.current.forEach((el, i) => {
      if (!el || reduced) return;
      gsap.to(el, {
        y: menu ? 0 : '112%',
        duration: 0.6,
        delay: menu ? i * 0.07 : 0,
        ease: 'power4.out',
      });
    });
  }, [menu, reduced]);

  /**
   * ── FIX FOUC: useLayoutEffect + GSAP ──────────────────────────────────────
   *
   * useLayoutEffect se dispara SÍNCRONO después de la mutación del DOM pero
   * ANTES de que el navegador pinte. Así GSAP fija los estados iniciales
   * (opacity:0, yPercent:115, etc.) antes del primer frame visible,
   * eliminando el parpadeo por completo.
   *
   * Flujo:
   *  1. setPhase('ready') → React re-renderiza, aplica className sin ocultamiento
   *  2. useLayoutEffect dispara → gsap.set() oculta elementos (pre-paint)
   *  3. Navegador pinta (elementos ya ocultos por GSAP)
   *  4. useGSAP crea el timeline de entrada
   */
  useLayoutEffect(() => {
    if (!ready || reduced) return;
    // Fijamos estados iniciales ANTES del paint para que no haya flash
    gsap.set('.n-el',   { opacity: 0, y: -14 });
    gsap.set('.h-ln',   { yPercent: 115 });
    gsap.set('.h-fd',   { opacity: 0, y: 16 });
    gsap.set('.memoji', { opacity: 0, x: 60 });
  }, [ready, reduced]);

  // ── Animaciones GSAP principales ──────────────────────────────────────────
  useGSAP(() => {
    if (reduced) return;

    // Scroll parallax — siempre activos (no dependen de ready)
    gsap.to('.h-txt', {
      yPercent: -6, ease: 'none',
      scrollTrigger: { trigger: '#hero', start: 'top top', end: 'bottom top', scrub: true },
    });
    gsap.to('.memoji', {
      yPercent: -10, ease: 'none',
      scrollTrigger: { trigger: '#hero', start: 'top top', end: 'bottom top', scrub: true },
    });

    // Reveal de títulos de sección
    document.querySelectorAll<HTMLElement>('.sec-h').forEach(el => {
      gsap.fromTo(el,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 0.75, ease: 'power3.out',
          scrollTrigger: { trigger: el, start: 'top 83%', once: true } }
      );
    });

    // ── ENTRADA ORQUESTADA DEL HERO (sólo cuando ready) ───────────────────
    // Los estados iniciales ya los fijó useLayoutEffect, así que no hay FOUC.
    if (ready) {
      const tl = gsap.timeline({ defaults: { ease: 'power4.out' } });
      tl
        // Nav items entran desde arriba
        .to('.n-el', { opacity: 1, y: 0, duration: 0.45, stagger: 0.05 })
        // Líneas de texto del hero suben desde su máscara
        .to('.h-ln', { yPercent: 0, duration: 1.2, stagger: 0.08 }, '-=0.35')
        // Elementos de subtítulo aparecen
        .to('.h-fd', { opacity: 1, y: 0, duration: 0.85, stagger: 0.06 }, '-=0.65')
        // Memoji entra desde la derecha
        .to('.memoji', { opacity: 1, x: 0, duration: 1.4, ease: 'power3.out' }, '-=1.2');
    }
  }, { scope: main, dependencies: [ready, reduced] });

  // Refresca ScrollTrigger después de que el contenido sea visible
  // ── FIX: TRANSICIÓN DE VUELTA INVISIBLE Y SCROLL EXACTO ────────────────
  useEffect(() => {
    if (!ready) return;

    const returnColor = sessionStorage.getItem('returnColor');
    
    if (returnColor) {
      // 1. Ponemos la cortina INMEDIATAMENTE para tapar el "Hero" al cargar
      const overlay = document.createElement('div');
      Object.assign(overlay.style, {
        position: 'fixed', inset: 0, backgroundColor: returnColor, zIndex: 99999,
        transform: 'scaleY(1)', transformOrigin: 'bottom' // Lista para subir
      });
      document.body.appendChild(overlay);

      // 2. Esperamos a que GSAP calcule las alturas y damos el salto invisible
      setTimeout(() => {
        const workSection = document.getElementById('work');
        if (workSection) {
          // behavior: 'auto' hace que el salto sea instantáneo (0 milisegundos)
          workSection.scrollIntoView({ behavior: 'auto' }); 
        }
        
        // 3. Subimos el telón suavemente para revelar los proyectos
        gsap.to(overlay, {
          scaleY: 0, duration: 0.7, ease: 'expo.inOut', delay: 0.1,
          onComplete: () => {
            overlay.remove();
            sessionStorage.removeItem('returnColor');
          }
        });
      }, 150);

    } else if (window.location.hash) {
      // Fallback normal por si alguien teclea la URL con #work directamente
      setTimeout(() => {
        const el = document.querySelector(window.location.hash);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    }
  }, [ready]);

  // ── Indicador deslizante de la nav ────────────────────────────────────────
  const onNavEnter = useCallback((e: React.MouseEvent<HTMLAnchorElement>) => {
    const el = e.currentTarget;
    if (!indRef.current || !navInner.current) return;
    const r  = el.getBoundingClientRect();
    const nr = navInner.current.getBoundingClientRect();
    gsap.to(indRef.current, {
      x: r.left - nr.left, width: r.width, height: r.height,
      duration: 0.38, ease: 'power3.out', opacity: 1,
    });
    el.style.color = 'var(--ink)';
  }, []);

  const onNavLeave = useCallback((e: React.MouseEvent<HTMLAnchorElement>) => {
    e.currentTarget.style.color = '';
  }, []);

  const onNavContainerLeave = useCallback(() => {
    const active = activeLinkRef.current;
    const nr = navInner.current?.getBoundingClientRect();
    if (active && nr && indRef.current) {
      const r = active.getBoundingClientRect();
      gsap.to(indRef.current, {
        x: r.left - nr.left, width: r.width, height: r.height,
        opacity: 0.65, duration: 0.45, ease: 'power3.out',
      });
    } else {
      gsap.to(indRef.current, { opacity: 0, duration: 0.25 });
    }
  }, []);

  // ── Guard: SSR / fase inicial ─────────────────────────────────────────────
  if (phase === 'checking') return null;

  // ── Renderizado principal ─────────────────────────────────────────────────
  return (
    <>
      {/* ── PRELOADER ── */}
      {phase === 'loading' && (
        <Preloader onDone={() => setPhase('splash')} />
      )}

      {/* ── IDENTITY SPLASH ── */}
      {phase === 'splash' && (
        <IdentitySplash
          lang={lang}
          onComplete={() => {
            sessionStorage.setItem('hasSeenIntro', 'true');
            setPhase('ready');
          }}
        />
      )}

      <InfallibleCursor />

      {cmd && (
        <CmdModal lang={lang} setLang={setLang} onClose={() => setCmd(false)} t={t} />
      )}

      {/* ── MENÚ OVERLAY MÓVIL ── */}
      <div
        role="dialog"
        aria-modal="true"
        aria-hidden={!menu}
        data-lenis-prevent="true"
        className="fixed inset-0 z-[80] bg-white/97 dark:bg-[#0a0a0a]/97 backdrop-blur-[40px] transition-[clip-path] duration-[650ms] [transition-timing-function:cubic-bezier(.76,0,.24,1)]"
        style={{ clipPath: menu ? 'inset(0)' : 'inset(100% 0 0 0)', pointerEvents: menu ? 'all' : 'none' }}
        data-noprint
      >
        <button
          onClick={() => setMenu(false)}
          className="absolute top-5 right-8 p-2 text-lead hover:text-ink transition-colors"
          aria-label="Cerrar menú"
        >
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M5 5l10 10M15 5L5 15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
        </button>
        <div className="h-full flex flex-col justify-center px-14">
          {t.menu.map((link, i) => (
            <div key={link} className="overflow-hidden leading-[1.05]">
              <a
                ref={el => { menuRefs.current[i] = el; }}
                href={t.hrefs[i]}
                className="font-black text-[clamp(2.5rem,8vw,6.5rem)] tracking-[-3px] text-ink no-underline block transition-colors duration-200 hover:text-brand"
                style={{ transform: 'translateY(112%)' }}
                onClick={() => setMenu(false)}
                aria-label={link}
              >
                {link}
              </a>
            </div>
          ))}
          <div className="flex gap-2 flex-wrap mt-10">
            {(Object.keys(LANG_LABELS) as Lang[]).map(l => (
              <button
                key={l}
                onClick={() => setLang(l)}
                data-h
                aria-label={`Idioma ${l}`}
                className={`font-mono text-[11px] tracking-[.15em] border-none rounded-[7px] px-2.5 py-1 transition-all duration-200 ${
                  lang === l
                    ? 'bg-ink text-page'
                    : 'bg-black/6 dark:bg-white/[0.06] text-lead hover:bg-black/10 dark:hover:bg-white/10'
                }`}
              >
                {l.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
        <div className="absolute bottom-8 left-14 right-14 flex justify-between">
          <span className="text-[10px] font-bold tracking-[.22em] uppercase text-lead/30">ENEKO RUIZ · 2026</span>
          <span className="text-[10px] font-bold tracking-[.22em] uppercase text-lead/20">DONOSTIA</span>
        </div>
      </div>

      {/* ────────────────────────────────────────────────────────────────────
       * CONTENIDO PRINCIPAL
       *
       * ⚠️  El div nunca usa opacity-100 vía CSS durante loading/splash.
       *     Solo GSAP lo revela cuando phase === 'ready', eliminando el FOUC.
       *
       * Durante loading/splash: visibility:hidden + pointer-events:none
       * Durante ready: GSAP anima los elementos individualmente
       * ──────────────────────────────────────────────────────────────────── */}
      <div
        ref={main}
        style={{
          // Durante loading: contraemos la altura para no afectar el layout
          height: (phase === 'loading' || phase === 'checking') ? 0 : undefined,
          overflow: (phase === 'loading' || phase === 'checking') ? 'hidden' : undefined,
          // Durante splash: invisible pero con layout correcto (GSAP puede medir)
          visibility: ready ? 'visible' : 'hidden',
          pointerEvents: ready ? 'auto' : 'none',
        }}
      >
        {/* ── HEADER FLOTANTE ── */}
        <header
          className="fixed top-3 left-1/2 -translate-x-1/2 z-[50] w-[calc(100%-2rem)] max-w-[940px]"
          data-noprint
        >
          <div className="flex items-center justify-between gap-4 px-5 py-[.62rem] rounded-full bg-white/82 dark:bg-[#0a0a0a]/82 backdrop-blur-3xl border border-white/80 dark:border-white/10 shadow-glass">

            <a href="#hero" className="n-el font-black text-[1rem] tracking-[-0.8px] text-ink no-underline shrink-0">
              Eneko.
            </a>

            <nav
              ref={navInner}
              className="hidden md:flex items-center relative gap-1"
              onMouseLeave={onNavContainerLeave}
            >
              {/* Indicador deslizante de nav activa */}
              <div
                ref={indRef}
                className="nav-ind absolute top-0 left-0 h-9 bg-black/5 dark:bg-white/10 rounded-xl opacity-0"
              />
              {t.menu.map((link, i) => (
                <a
                  key={link}
                  href={t.hrefs[i]}
                  className="n-el relative z-[1] text-[13px] font-semibold text-lead no-underline px-[14px] py-[7px]"
                  onMouseEnter={onNavEnter}
                  onMouseLeave={onNavLeave}
                >
                  {link}
                </a>
              ))}
            </nav>

            <div className="n-el flex items-center gap-2 shrink-0">
              <LangDD lang={lang} setLang={setLang} />
              <ThemeToggle />
              <button
                onClick={() => setCmd(true)}
                aria-label="Abrir búsqueda"
                className="p-2 border border-black/10 dark:border-white/10 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <Search size={14} />
              </button>
              <button
                onClick={() => setMenu(true)}
                aria-label="Abrir menú"
                data-h
                className="md:hidden font-bold text-[12px] text-lead tracking-[.1em] bg-none border-none p-2"
              >
                MENU
              </button>
            </div>
          </div>
        </header>

        {/* ════ SECCIONES ════ */}
        <Hero       t={t} greeting={greeting} reduced={reduced} setMag={() => {}} />
        <Skills     t={t} />
        <Projects   t={t} top3={top3} repos={repos} load={load} offline={offline} BranchMergeBtn={BranchMergeBtn} />
        <About      t={t} />
        <Philosophy t={t} />
        <Contact    t={t} />
        <SiteFooter t={t} />
      </div>
    </>
  );
}
