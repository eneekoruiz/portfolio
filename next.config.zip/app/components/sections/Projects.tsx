'use client';

/**
 * ─────────────────────────────────────────────────────────────────────────────
 * PROJECTS SECTION — Selected Works + GitHub Activity
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * CAMBIOS VS. VERSIÓN ANTERIOR:
 *
 * 1. TIPOGRAFÍA COMPACTA — Titles pasaron de clamp(1.7rem,6vw,4rem) a
 *    clamp(1rem,2.2vw,1.5rem). Padding vertical reducido de py-10 a py-4.
 *    El acordeón ahora es una "Bento Row" compacta, no un elemento gigante.
 *
 * 2. PERSISTENCIA DE SCROLL (UX crítica) — Al abrir un acordeón guardamos
 *    en sessionStorage {openIdx, scrollY}. Al volver de /work/[id], Projects
 *    lee ese estado y restaura posición + acordeón abierto. Se limpia al
 *    cerrar el acordeón manualmente.
 *
 * 3. GSAP SIN FUGAS — Todos los efectos están dentro de gsap.context()
 *    con cleanup .revert() garantizado.
 *
 * 4. TRANSICIÓN DE PÁGINA — overlay animado con color del proyecto antes de
 *    navegar a /work/[id].
 * ─────────────────────────────────────────────────────────────────────────────
 */

'use client';

import { useRef, useEffect, useState, useLayoutEffect } from 'react';
import { useRouter }   from 'next/navigation';
import gsap            from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Github, ArrowUpRight, ArrowRight,
  Activity, Code2, Loader2, ChevronDown,
} from 'lucide-react';
import { LANG_COLORS } from '../../lib/constants';
import type { ProjectCard, RepoFull, Tx } from '../../lib/types';

if (typeof window !== 'undefined') gsap.registerPlugin(ScrollTrigger);

// ── Constantes ────────────────────────────────────────────────────────────────

/** Fases del ciclo de vida de ingeniería mostradas en la tarjeta lifecycle */
const LIFECYCLE = [
  'System Architecture',
  'Core Development',
  'Production Deployment',
  'Security & Audit',
] as const;

/** sessionStorage key para persistencia de scroll/acordeón */
const SESSION_KEY = 'projects_nav_state';

/**
 * Temas por proyecto: color de acento, gradiente de fondo,
 * progreso en el lifecycle (1–4) y CTA del botón.
 */
const PROJ_THEMES: Record<string, {
  color: string;
  img: string;
  progress: number;
  btnText: string;
  hasAudit: boolean;
}> = {
  'ana-peluquera': {
    color: '#ff2d78',
    img: 'radial-gradient(circle at 50% 100%, #ff2d7815 0%, transparent 60%)',
    progress: 4, btnText: 'Ver Auditoría', hasAudit: true,
  },
  'who-are-ya-backend': {
    color: '#00ff41',
    img: 'radial-gradient(circle at 50% 100%, #00ff4115 0%, transparent 60%)',
    progress: 4, btnText: 'Ver Auditoría', hasAudit: true,
  },
  'rides24ofiziala': {
    color: '#f59e0b',
    img: 'radial-gradient(circle at 50% 100%, #f59e0b15 0%, transparent 60%)',
    progress: 3, btnText: 'Ver Repositorio', hasAudit: false,
  },
  'spotshare-parking': {
    color: '#00f0ff',
    img: 'radial-gradient(circle at 50% 100%, #00f0ff15 0%, transparent 60%)',
    progress: 2, btnText: 'Ver Repositorio', hasAudit: false,
  },
  'pke_web': {
    color: '#b026ff',
    img: 'radial-gradient(circle at 50% 100%, #b026ff15 0%, transparent 60%)',
    progress: 4, btnText: 'Ver Auditoría', hasAudit: true,
  },
};

const DEFAULT_THEME = {
  color: '#888', img: 'none', progress: 1, btnText: 'Source Code', hasAudit: false,
};

// ── Helpers de persistencia ───────────────────────────────────────────────────

interface NavState { openIdx: number | null; scrollY: number; }

function saveNavState(state: NavState) {
  try { sessionStorage.setItem(SESSION_KEY, JSON.stringify(state)); } catch (_) {}
}

function loadNavState(): NavState | null {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) as NavState : null;
  } catch (_) { return null; }
}

function clearNavState() {
  try { sessionStorage.removeItem(SESSION_KEY); } catch (_) {}
}

// ── RepoRow (actividad de GitHub) ─────────────────────────────────────────────

interface RepoRowProps {
  r: RepoFull;
  idx: number;
  activeRepo: number | null;
  setActiveRepo: (i: number | null) => void;
  lineRef: (el: HTMLDivElement | null) => void;
}

function RepoRow({ r, idx, activeRepo, setActiveRepo, lineRef }: RepoRowProps) {
  const isActive = activeRepo === idx;

  return (
    <div
      ref={lineRef}
      className="border-b border-black/7 dark:border-white/10 transition-colors duration-200 hover:bg-black/[0.02] dark:hover:bg-white/[0.02]"
    >
      <div
        className="py-4 cursor-pointer relative z-10"
        onMouseEnter={() => window.innerWidth > 768 && setActiveRepo(idx)}
        onMouseLeave={() => window.innerWidth > 768 && setActiveRepo(null)}
        onClick={() => window.innerWidth <= 768 && setActiveRepo(isActive ? null : idx)}
      >
        <div className="flex items-start md:items-center gap-4 md:gap-5">
          <span className="font-mono text-[10px] text-lead/40 w-6 shrink-0 pt-1 md:pt-0">
            {String(idx + 1).padStart(2, '0')}
          </span>
          <div className="flex-1 min-w-0">
            <div className="flex flex-col md:flex-row md:items-center gap-y-2 gap-x-3">
              <span className={`font-mono text-[13px] font-bold md:font-medium transition-colors duration-200 ${isActive ? 'text-brand' : 'text-ink'}`}>
                {r.name}
              </span>
              <div className="flex flex-wrap gap-[0.3rem]">
                {r.langs?.map(l => (
                  <span key={l} className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-medium bg-black/5 dark:bg-white/[0.03] border border-black/8 dark:border-white/10 text-lead whitespace-nowrap">
                    <span
                      className="w-[5px] h-[5px] rounded-full shrink-0"
                      style={{
                        background: LANG_COLORS[l] ?? '#999',
                        filter: isActive ? `drop-shadow(0 0 4px ${LANG_COLORS[l] ?? '#999'})` : 'none',
                        transition: 'filter .2s',
                      }}
                    />
                    {l}
                  </span>
                ))}
              </div>
            </div>
            {/* Expansión inline en móvil */}
            <div className={`overflow-hidden transition-[max-height,opacity] duration-300 ${isActive ? 'max-h-40 opacity-100 mt-3' : 'max-h-0 opacity-0'}`}>
              {r.description && (
                <p className="text-[11px] text-lead leading-[1.6] mb-3 pr-4">{r.description}</p>
              )}
              <a
                href={r.html_url} target="_blank" rel="noopener noreferrer"
                onClick={e => e.stopPropagation()}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-ink text-page text-[9px] font-bold uppercase tracking-widest hover:scale-105 transition-transform"
              >
                Visitar Repo <ArrowUpRight size={12} />
              </a>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-4 shrink-0">
            <span className="font-mono text-[10px] text-lead/40">{(r.size / 1024).toFixed(1)}MB</span>
            {r.stargazers_count > 0 && (
              <span className="text-[10px] text-lead/40">★{r.stargazers_count}</span>
            )}
            <span className="font-mono text-[10px] text-lead/30">
              {new Date(r.pushed_at).getFullYear()}
            </span>
            <ArrowUpRight
              size={14}
              className={`transition-all duration-200 ${isActive ? 'text-brand opacity-100' : 'text-lead opacity-30'}`}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── PremiumWorkRow — Acordeón Bento Compacto ──────────────────────────────────

interface WorkRowProps {
  proj: ProjectCard;
  idx: number;
  isExpanded: boolean;
  onToggle: () => void;
}

function PremiumWorkRow({ proj, idx, isExpanded, onToggle }: WorkRowProps) {
  const [isNavigating, setIsNavigating] = useState(false);
  const rowRef    = useRef<HTMLDivElement>(null);
  const bodyRef   = useRef<HTMLDivElement>(null);
  const router    = useRouter();

  const safeId = proj.name.toLowerCase().replace(/[\s_]+/g, '-');
  const theme  = PROJ_THEMES[safeId] ?? DEFAULT_THEME;

  // ── Animación de apertura/cierre del acordeón con GSAP ───────────────────
  useEffect(() => {
    const body = bodyRef.current;
    if (!body) return;
    gsap.to(body, {
      height: isExpanded ? 'auto' : 0,
      opacity: isExpanded ? 1 : 0,
      duration: 0.5,
      ease: isExpanded ? 'expo.out' : 'expo.inOut',
    });
  }, [isExpanded]);

  // ── Scroll suave al row en móvil al abrirse ───────────────────────────────
  useEffect(() => {
    if (isExpanded && rowRef.current && window.innerWidth <= 768) {
      setTimeout(() => {
        const y = rowRef.current!.getBoundingClientRect().top + window.scrollY - 90;
        window.scrollTo({ top: y, behavior: 'smooth' });
      }, 180);
    }
  }, [isExpanded]);

  /**
   * handleNavigate — Transición cinematográfica al detalle de proyecto
   *
   * 1. Guarda el estado de scroll + acordeón en sessionStorage
   * 2. Crea un overlay con el color del proyecto
   * 3. Anima el overlay para cubrir la pantalla
   * 4. Navega a /work/[id]
   */
  const handleNavigate = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isNavigating) return;
    setIsNavigating(true);

    // Guardar estado para restaurar al volver
    saveNavState({ openIdx: idx, scrollY: window.scrollY });

    // Cleanup de overlay residual
    document.getElementById('project-transition-layer')?.remove();

    const overlay = document.createElement('div');
    overlay.id = 'project-transition-layer';
    Object.assign(overlay.style, {
      position: 'fixed', inset: '0',
      backgroundColor: theme.color,
      zIndex: '99999',
      transform: 'scaleY(0)',
      transformOrigin: 'bottom',
      pointerEvents: 'all',
    });
    document.body.appendChild(overlay);

    gsap.to(overlay, {
      scaleY: 1,
      duration: 0.5,
      ease: 'expo.inOut',
      onComplete: () => {
        router.push(`/work/${safeId}`);
        // Fade out suave para revelar la nueva página
        gsap.to(overlay, {
          opacity: 0,
          duration: 0.6,
          delay: 0.35,
          onComplete: () => overlay.remove(),
        });
      },
    });

    // Seguro: resetear si el usuario cancela (botón atrás del navegador)
    setTimeout(() => setIsNavigating(false), 2500);
  };

  return (
    <div
      ref={rowRef}
      className={`group/row relative border-b border-black/10 dark:border-white/10 transition-colors duration-300 ${
        isExpanded ? 'bg-black/[0.015] dark:bg-white/[0.015]' : ''
      }`}
    >
      {/* Glow de fondo al hover (desktop) */}
      <div
        className="absolute inset-0 z-0 opacity-0 group-hover/row:opacity-100 transition-opacity duration-500 pointer-events-none hidden md:block"
        style={{ background: theme.img }}
      />

      {/* ── CABECERA DEL ACORDEÓN (compacta) ── */}
      <button
        onClick={onToggle}
        aria-expanded={isExpanded}
        className="relative z-10 w-full text-left py-4 md:py-5 px-0 md:px-6 flex items-center justify-between gap-4 cursor-pointer"
      >
        {/* Número de orden */}
        <span
          className="font-mono text-[10px] w-6 shrink-0 tabular-nums transition-colors duration-300"
          style={{ color: isExpanded ? theme.color : 'var(--lead)', opacity: isExpanded ? 1 : 0.4 }}
        >
          {String(idx + 1).padStart(2, '0')}
        </span>

        {/* Nombre del proyecto — tipografía compacta */}
        <div className="flex-1 min-w-0 flex items-baseline gap-3 md:gap-5">
          <h3
            className="font-bold text-[clamp(0.95rem,2.2vw,1.45rem)] leading-tight tracking-tight truncate transition-colors duration-300"
            style={{ color: isExpanded ? theme.color : 'var(--ink)' }}
          >
            {proj.name.replace(/-/g, ' ')}
          </h3>
          {/* Tag — oculto en mobile muy pequeño */}
          <span
            className="hidden sm:block font-mono text-[9px] uppercase tracking-[0.25em] opacity-40 group-hover/row:opacity-80 transition-opacity whitespace-nowrap"
            style={{ color: theme.color }}
          >
            {proj.tag}
          </span>
        </div>

        {/* Año */}
        <span className="hidden md:block font-mono text-[11px] text-lead/40 shrink-0">
          {proj.year}
        </span>

        {/* Chevron animado */}
        <div
          className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all duration-400 ${
            isExpanded
              ? 'bg-ink text-page dark:bg-white dark:text-black rotate-180'
              : 'border border-black/10 dark:border-white/15 text-lead group-hover/row:border-brand group-hover/row:text-brand'
          }`}
        >
          <ChevronDown size={15} strokeWidth={2} />
        </div>
      </button>

      {/* ── CUERPO DEL ACORDEÓN (Bento Box) ── */}
      {/* height:0 inicial — GSAP lo anima a 'auto' al abrir */}
      <div ref={bodyRef} style={{ height: 0, overflow: 'hidden', opacity: 0 }}>
        <div className="pb-6 md:pb-10 pt-1 px-0 md:px-6 grid grid-cols-1 lg:grid-cols-[1.2fr_2fr] gap-3 md:gap-4 relative z-10">

          {/* Tarjeta: Project Lifecycle */}
          <div
            className="p-5 md:p-6 rounded-2xl flex flex-col justify-between relative overflow-hidden group/card"
            style={{
              backgroundColor: `${theme.color}05`,
              border: `1px solid ${theme.color}25`,
            }}
          >
            {/* Glow ambiental */}
            <div
              className="absolute top-0 right-0 w-28 h-28 blur-[60px] opacity-25 transition-opacity duration-700 group-hover/card:opacity-50 pointer-events-none"
              style={{ backgroundColor: theme.color }}
            />

            <div className="relative z-10">
              <span className="font-mono text-[9px] uppercase tracking-[0.35em] opacity-40">
                Project Lifecycle
              </span>

              <div className="mt-5">
                {LIFECYCLE.map((stage, i) => {
                  const completed = i < theme.progress;
                  const active    = i === theme.progress - 1;
                  return (
                    <div key={stage} className="flex items-start gap-3 relative">
                      {/* Línea vertical conectora */}
                      {i !== LIFECYCLE.length - 1 && (
                        <div
                          className="absolute left-[4px] top-[11px] w-[1px] h-full"
                          style={{
                            background: completed && !active ? theme.color : 'currentColor',
                            opacity:    completed && !active ? 0.35 : 0.05,
                          }}
                        />
                      )}
                      {/* Punto de estado */}
                      <div className="relative flex items-center justify-center w-2.5 h-2.5 mt-1 shrink-0 z-10">
                        <div
                          className={`w-1.5 h-1.5 rounded-full ${!completed ? 'bg-black/10 dark:bg-white/10' : ''}`}
                          style={{ backgroundColor: completed ? theme.color : undefined }}
                        />
                        {active && (
                          <div
                            className="absolute inset-0 rounded-full animate-ping opacity-50"
                            style={{ backgroundColor: theme.color }}
                          />
                        )}
                      </div>
                      {/* Etiqueta */}
                      <div
                        className={`pb-4 font-mono text-[8px] md:text-[9px] uppercase tracking-[0.2em] ${completed ? 'opacity-80' : 'opacity-25'} ${active ? 'font-bold' : ''}`}
                        style={{ color: active ? theme.color : 'inherit' }}
                      >
                        {stage}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* CTA */}
            {theme.hasAudit ? (
              <a
                href={`/work/${safeId}`}
                onClick={handleNavigate}
                className={`relative z-10 mt-4 flex items-center justify-between px-5 py-3 rounded-full shadow-lg transition-all duration-300 text-page ${
                  isNavigating ? 'bg-ink/70 cursor-wait' : 'bg-ink hover:scale-[1.03] active:scale-95'
                }`}
              >
                <span className="font-bold text-[10px] uppercase tracking-widest flex items-center gap-2">
                  <Activity size={13} className={isNavigating ? '' : 'animate-pulse'} />
                  {isNavigating ? 'CARGANDO...' : theme.btnText}
                </span>
                {isNavigating
                  ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  : <ArrowRight className="w-3.5 h-3.5" />
                }
              </a>
            ) : (
              <a
                href={`https://github.com/eneekoruiz/${proj.name}`}
                target="_blank" rel="noopener noreferrer"
                onClick={e => e.stopPropagation()}
                className="relative z-10 mt-4 flex items-center justify-between px-5 py-3 rounded-full border border-black/15 dark:border-white/15 hover:bg-black/5 dark:hover:bg-white/5 hover:scale-[1.03] active:scale-95 transition-all"
              >
                <span className="font-bold text-[10px] uppercase tracking-widest flex items-center gap-2">
                  <Code2 size={13} /> {theme.btnText}
                </span>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-40" />
              </a>
            )}
          </div>

          {/* Tarjeta: Información del proyecto */}
          <div className="p-5 md:p-6 rounded-2xl border border-black/5 dark:border-white/5 bg-black/[0.015] dark:bg-white/[0.015] flex flex-col justify-between gap-5">
            <p className="text-sm md:text-base font-light leading-relaxed opacity-85 max-w-2xl">
              {proj.desc}
            </p>

            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-black/5 dark:border-white/5">
              <div className="space-y-1">
                <span className="block font-mono text-[8px] uppercase tracking-[0.35em] opacity-35">Año</span>
                <span className="block font-medium text-sm">{proj.year}</span>
              </div>
              <div className="space-y-1">
                <span className="block font-mono text-[8px] uppercase tracking-[0.35em] opacity-35">Tamaño</span>
                <span className="block font-medium text-sm">{proj.size}</span>
              </div>
              <div className="col-span-2 space-y-2">
                <span className="block font-mono text-[8px] uppercase tracking-[0.35em] opacity-35">Stack</span>
                <div className="flex flex-wrap gap-1.5">
                  {proj.langs.map(l => (
                    <span
                      key={l}
                      className="px-2.5 py-1 rounded-full border border-black/10 dark:border-white/10 text-[9px] font-medium tracking-wide bg-black/[0.025] dark:bg-white/[0.025]"
                    >
                      {l}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

// ── Skeleton de carga ─────────────────────────────────────────────────────────

function SkeletonRow({ idx }: { idx: number }) {
  return (
    <div
      className="border-b border-black/5 dark:border-white/5 py-5 px-0 md:px-6 flex items-center justify-between animate-pulse"
      style={{ animationDelay: `${idx * 0.08}s` }}
    >
      <div className="flex items-center gap-5">
        <span className="w-4 h-3 rounded bg-black/8 dark:bg-white/8" />
        <span className="block h-5 w-48 md:w-64 rounded-lg bg-black/5 dark:bg-white/5" />
      </div>
      <span className="block h-8 w-8 rounded-full bg-black/5 dark:bg-white/5" />
    </div>
  );
}

// ── Componente principal ──────────────────────────────────────────────────────

interface ProjectsProps {
  t: Tx;
  top3: ProjectCard[];
  repos: RepoFull[];
  load: boolean;
  offline: boolean;
  BranchMergeBtn: React.ComponentType<{ label: string; href: string }>;
}

export function Projects({ t, top3, repos, load, offline, BranchMergeBtn }: ProjectsProps) {
  const [expandedIdx, setExpandedIdx]   = useState<number | null>(null);
  const [activeRepo,  setActiveRepo]    = useState<number | null>(null);
  const lineRefs  = useRef<(HTMLDivElement | null)[]>([]);
  const sectionRef = useRef<HTMLElement>(null);

  /**
   * Restaurar estado (scroll + acordeón abierto) al volver de /work/[id].
   * useLayoutEffect para que el scroll se aplique antes del primer paint
   * y no haya salto visual.
   */
  useLayoutEffect(() => {
    if (load || top3.length === 0) return;

    const saved = loadNavState();
    if (!saved) return;

    // Restaurar acordeón abierto
    setExpandedIdx(saved.openIdx);

    // Restaurar posición de scroll con un pequeño retraso para que
    // el layout ya esté completo
    const id = setTimeout(() => {
      window.scrollTo({ top: saved.scrollY, behavior: 'instant' as ScrollBehavior });
      clearNavState(); // Limpiar después de restaurar
    }, 80);

    return () => clearTimeout(id);
  }, [load, top3.length]);

  // ── Animaciones de entrada ────────────────────────────────────────────────
  useEffect(() => {
    if (load) return;
    const ctx = gsap.context(() => {
      gsap.fromTo('.projects-header',
        { opacity: 0, y: 40 },
        {
          opacity: 1, y: 0, duration: 0.8, ease: 'expo.out',
          scrollTrigger: { trigger: sectionRef.current, start: 'top 85%', once: true },
        }
      );
      gsap.fromTo('.work-row-anim',
        { opacity: 0, y: 20 },
        {
          opacity: 1, y: 0, duration: 0.5, stagger: 0.04, ease: 'power3.out',
          scrollTrigger: { trigger: '.projects-list', start: 'top 90%', once: true },
        }
      );
    });
    return () => ctx.revert();
  }, [load]);

  /**
   * Toggle del acordeón:
   * - Si se abre uno, guarda el estado de scroll.
   * - Si se cierra, limpia el estado guardado.
   */
  const handleToggle = (idx: number) => {
    setExpandedIdx(prev => {
      const next = prev === idx ? null : idx;
      if (next !== null) {
        saveNavState({ openIdx: next, scrollY: window.scrollY });
      } else {
        clearNavState();
      }
      return next;
    });
  };

  return (
    <>
      {/* ════ SELECTED WORKS ════ */}
      <section
        ref={sectionRef}
        id="work"
        className="py-16 md:py-28 px-5 md:px-8 max-w-[1300px] mx-auto relative z-20"
      >
        {/* Encabezado de sección */}
        <div className="projects-header mb-10 md:mb-18">
          <div className="flex items-center gap-4 mb-5">
            <div className="h-[1px] w-8 md:w-10 bg-ink opacity-20" />
            <p className="font-mono text-[9px] font-bold tracking-[0.3em] uppercase text-lead/60">
              {t.woLb || 'PORTFOLIO DE INGENIERÍA'}
            </p>
          </div>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <h2 className="font-black text-[clamp(2.6rem,7vw,5.5rem)] tracking-tighter leading-[0.88] text-ink uppercase italic">
              Selected<br/>Works.
            </h2>
            <span className="text-[9px] font-bold uppercase tracking-[0.2em] opacity-35 mb-1">
              Click to expand ↓
            </span>
          </div>
        </div>

        {/* Lista de proyectos */}
        <div className="projects-list border-t border-black/10 dark:border-white/10">
          {(load || top3.length === 0)
            ? [0, 1, 2, 3, 4].map(i => (
                <div key={i} className="work-row-anim">
                  <SkeletonRow idx={i} />
                </div>
              ))
            : top3.map((p, i) => (
                <div key={p.n} className="work-row-anim">
                  <PremiumWorkRow
                    proj={p}
                    idx={i}
                    isExpanded={expandedIdx === i}
                    onToggle={() => handleToggle(i)}
                  />
                </div>
              ))
          }
        </div>
      </section>

      {/* ════ GITHUB ACTIVITY ════ */}
      <section
        id="github"
        data-section="github"
        className="border-t border-black/7 dark:border-white/10 py-14 md:py-22 px-5 md:px-8 max-w-[1200px] mx-auto relative z-10"
      >
        <div className="flex items-end justify-between pb-4 border-b border-black/7 dark:border-white/10 mb-1">
          <p className="text-[9px] font-bold tracking-[0.22em] uppercase text-lead/60">
            {t.ghLb || 'ACTIVIDAD'}
          </p>
          <span className="font-mono text-[9px] text-lead/40">
            {repos?.length || 0}_repos
          </span>
        </div>

        <div className="min-h-[200px]">
          {load ? (
            <div className="py-4">
              {[0, 1, 2, 3].map(i => (
                <div
                  key={i}
                  className="border-b border-black/7 dark:border-white/10 py-5 flex items-center gap-5 animate-pulse"
                  style={{ animationDelay: `${i * 0.07}s` }}
                >
                  <span className="w-5 h-3 rounded bg-black/8 dark:bg-white/8 shrink-0" />
                  <span className="h-4 flex-1 max-w-[220px] rounded bg-black/8 dark:bg-white/8" />
                </div>
              ))}
            </div>
          ) : (
            <div>
              {repos.slice(0, 10).map((r, i) => (
                <RepoRow
                  key={r.id}
                  r={r}
                  idx={i}
                  activeRepo={activeRepo}
                  setActiveRepo={setActiveRepo}
                  lineRef={el => { lineRefs.current[i] = el; }}
                />
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-center mt-10 md:mt-12">
          <BranchMergeBtn
            label={t.moreGh || 'VER TODO EN GITHUB'}
            href="https://github.com/eneekoruiz"
          />
        </div>
      </section>
    </>
  );
}
